﻿using UnityEngine;
using System.Collections;
using Panda;

namespace Panda.Examples.Shooter
{
    public class TriggerType : MonoBehaviour
    {
        public bool collidesWithBullet = false;
        public bool collidesWithVision = false;
    }

}
